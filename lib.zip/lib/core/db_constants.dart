class DBConstants{

  DBConstants._();

  static String singleMovieKey='singleMovie';
}