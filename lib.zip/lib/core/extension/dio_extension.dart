import 'dart:io';

import 'package:dio/dio.dart';

extension DioErrorX on DioError {
  bool get isNoConnectionError =>
      type == DioErrorType.connectionError && error is SocketException;

  bool get isUnauthorizedAccess =>
      type == DioErrorType.badResponse && response?.statusCode == 401;

  String get serverErrorMessage => 'Server Error';
  String get unAuthorizedMessage => 'You are unauthorized error';
}

extension StringX on String {
  int get parseToInt => int.parse(this);
}
